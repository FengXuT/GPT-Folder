var P=Object.defineProperty;var O=(r,e,t)=>e in r?P(r,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[e]=t;var p=(r,e,t)=>O(r,typeof e!="symbol"?e+"":e,t);const y="未命名对话";function C(r){try{const t=new URL(r).pathname.split("/").filter(Boolean),n=t.indexOf("c"),o=n>=0?t[n+1]:null;return o&&/^[a-zA-Z0-9_-]+$/.test(o)?o:null}catch{return null}}function k(r){return r.replace(/\s*[-|]\s*ChatGPT\s*$/i,"").replace(/^ChatGPT\s*[-|]\s*/i,"").trim()||y}function q(){var e;const r=["main h1","main [data-testid='conversation-title']","h1"];for(const t of r){const n=document.querySelector(t),o=(e=n==null?void 0:n.innerText)==null?void 0:e.trim();if(o)return o}return null}function v(){const r=C(window.location.href);if(!r)return null;const e=q(),t=k(e||document.title||y);return{id:r,title:t,url:window.location.href}}function $(r){let e=window.location.href,t=0;const n=()=>{window.cancelAnimationFrame(t),t=window.requestAnimationFrame(()=>{e!==window.location.href&&(e=window.location.href,r())})},o=new MutationObserver(n);o.observe(document.documentElement,{childList:!0,subtree:!0});const i=s=>{const c=history[s];return history[s]=function(B,L,R){const H=c.call(history,B,L,R);return window.dispatchEvent(new Event("chatgpt-folders-route-change")),H},()=>{history[s]=c}},a=i("pushState"),d=i("replaceState");return window.addEventListener("popstate",n),window.addEventListener("chatgpt-folders-route-change",n),()=>{o.disconnect(),a(),d(),window.removeEventListener("popstate",n),window.removeEventListener("chatgpt-folders-route-change",n),window.cancelAnimationFrame(t)}}const g="chatgptFoldersState",E=1;function F(){var e,t;const r=(t=(e=globalThis.chrome)==null?void 0:e.storage)==null?void 0:t.sync;if(!r)throw new Error("chrome.storage.sync is unavailable.");return{get:n=>new Promise((o,i)=>{r.get(n??null,a=>{var s,c;const d=(c=(s=globalThis.chrome)==null?void 0:s.runtime)==null?void 0:c.lastError;if(d){i(new Error(d.message));return}o(a)})}),set:n=>new Promise((o,i)=>{r.set(n,()=>{var d,s;const a=(s=(d=globalThis.chrome)==null?void 0:d.runtime)==null?void 0:s.lastError;if(a){i(new Error(a.message));return}o()})})}}function f(){return new Date().toISOString()}function z(r){var t,n;const e=((n=(t=globalThis.crypto)==null?void 0:t.randomUUID)==null?void 0:n.call(t))??Math.random().toString(36).slice(2);return`${r}_${e}`}function D(r){if(!r||typeof r!="object")return null;const e=r;if(typeof e.id!="string"||typeof e.name!="string")return null;const t=typeof e.createdAt=="string"?e.createdAt:f(),n=typeof e.updatedAt=="string"?e.updatedAt:t;return{id:e.id,name:e.name.trim()||"未命名文件夹",createdAt:t,updatedAt:n}}function N(r){if(!r||typeof r!="object")return null;const e=r;if(typeof e.id!="string"||typeof e.title!="string"||typeof e.url!="string")return null;const t=typeof e.createdAt=="string"?e.createdAt:f(),n=typeof e.updatedAt=="string"?e.updatedAt:t,o=typeof e.lastSeenAt=="string"?e.lastSeenAt:n,i=typeof e.folderId=="string"?e.folderId:null;return{id:e.id,title:e.title.trim()||"未命名对话",url:e.url,folderId:i,createdAt:t,updatedAt:n,lastSeenAt:o}}function S(r,e){const t=r==null?void 0:r.trim();return t||e.trim()||"未命名对话"}function U(){return{version:E,folders:[],conversations:[]}}function A(r){if(!r||typeof r!="object")return U();const e=r,t=Array.isArray(e.folders)?e.folders.map(D).filter(i=>!!i):[],n=new Set(t.map(i=>i.id)),o=Array.isArray(e.conversations)?e.conversations.map(N).filter(i=>!!i).map(i=>({...i,folderId:i.folderId&&n.has(i.folderId)?i.folderId:null})):[];return{version:E,folders:t,conversations:o}}async function T(){const r=await F().get(g);return A(r[g])}async function G(r){await F().set({[g]:A(r)})}async function m(r){const e=await T(),t=r(e);return await G(e),t}async function W(r){const e=r.trim();if(!e)throw new Error("Folder name is required.");return m(t=>{const n=f(),o={id:z("folder"),name:e,createdAt:n,updatedAt:n};return t.folders.push(o),o})}async function _(r,e){const t=e.trim();if(!t)throw new Error("Folder name is required.");await m(n=>{const o=n.folders.find(i=>i.id===r);if(!o)throw new Error("Folder not found.");o.name=t,o.updatedAt=f()})}async function j(r){await m(e=>{e.folders=e.folders.filter(t=>t.id!==r),e.conversations=e.conversations.map(t=>t.folderId===r?{...t,folderId:null,updatedAt:f()}:t)})}async function V(r,e){return m(t=>{if(!t.folders.some(a=>a.id===e))throw new Error("Folder not found.");const n=f(),o=t.conversations.find(a=>a.id===r.id);if(o)return o.title=S(o.title,r.title),o.url=r.url,o.folderId=e,o.lastSeenAt=n,o.updatedAt=n,o;const i={id:r.id,title:r.title.trim()||"未命名对话",url:r.url,folderId:e,createdAt:n,updatedAt:n,lastSeenAt:n};return t.conversations.push(i),i})}async function Z(r,e){return m(t=>{if(!t.folders.some(i=>i.id===e))throw new Error("Folder not found.");const n=f(),o=[];for(const i of r){const a=t.conversations.find(s=>s.id===i.id);if(a){a.title=S(a.title,i.title),a.url=i.url,a.folderId=e,a.lastSeenAt=n,a.updatedAt=n,o.push(a);continue}const d={id:i.id,title:i.title.trim()||"未命名对话",url:i.url,folderId:e,createdAt:n,updatedAt:n,lastSeenAt:n};t.conversations.push(d),o.push(d)}return o})}async function K(r,e){const t=e.trim();if(!t)throw new Error("Conversation title is required.");await m(n=>{const o=n.conversations.find(i=>i.id===r);if(!o)throw new Error("Conversation not found.");o.title=t,o.updatedAt=f()})}async function X(r){await m(e=>{const t=e.conversations.find(n=>n.id===r);if(!t)throw new Error("Conversation not found.");t.folderId=null,t.updatedAt=f()})}async function Y(r,e){const t=e??v();if(!t)throw new Error("Open a saved ChatGPT conversation before assigning it to a folder.");return V(t,r)}const x="chatgpt-folders-extension-root",l={folders:"Folders",search:"搜索文件夹",searchPlaceholder:"搜索文件夹或对话",createFolder:"新建文件夹",batchAdd:"批量加入历史对话",renameFolder:"重命名文件夹",renameConversation:"重命名对话",deleteFolder:"删除文件夹",folderNamePrompt:"文件夹名称",newFolderPrompt:"新文件夹名称",addCurrent:"加入当前对话",addSelected:"加入选中",cancel:"取消",remove:"移出列表",noFolders:"还没有文件夹",noConversations:"还没有对话",noCurrent:"打开已保存对话后可加入",noHistory:"左侧栏暂未读到历史对话",selectFolder:"选择目标文件夹",collapse:"折叠",expand:"展开",menu:"菜单",deleteConfirmPrefix:"删除文件夹",deleteConfirmSuffix:"？其中的对话会变为未归类。"},h={search:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 21-4.3-4.3m1.3-5.2a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0Z"/></svg>',folder:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5Z"/></svg>',folderPlus:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5Z"/><path d="M12 11v5m-2.5-2.5h5"/></svg>',batch:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 7h10M9 12h10M9 17h10"/><path d="m4 7 .8.8L6.5 6M4 12l.8.8 1.7-1.8M4 17l.8.8 1.7-1.8"/></svg>',more:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 7.5h.01M12 12h.01M12 16.5h.01"/></svg>',chevronDown:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>',chevronRight:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',plus:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',edit:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h8"/><path d="M16.8 4.2a2 2 0 0 1 2.8 2.8L8 18.6 4.5 19.5 5.4 16Z"/></svg>',trash:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M9 7V5.5h6V7m-5 4v5m4-5v5M7 7l1 13h8l1-13"/></svg>'},J=`
  :host {
    color-scheme: light dark;
    clear: both;
    display: block;
    flex: none;
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    margin: 8px 0;
    min-width: 0;
    width: 100%;
  }

  * {
    box-sizing: border-box;
  }

  .cf-section {
    color: var(--text-primary, CanvasText);
    font-size: 14px;
    line-height: 1.35;
    min-width: 0;
    width: 100%;
  }

  .cf-header {
    display: flex;
    align-items: center;
    height: 32px;
    gap: 6px;
    padding: 0 20px;
    position: relative;
  }

  .cf-title {
    flex: 1;
    min-width: 0;
    color: color-mix(in srgb, CanvasText 82%, transparent);
    font-weight: 500;
  }

  .cf-icon-button {
    display: inline-grid;
    flex: none;
    place-items: center;
    width: 26px;
    height: 26px;
    border: 0;
    border-radius: 8px;
    background: transparent;
    color: color-mix(in srgb, CanvasText 72%, transparent);
    cursor: pointer;
    padding: 0;
  }

  .cf-icon-button svg,
  .cf-folder-icon svg,
  .cf-menu-item svg {
    width: 18px;
    height: 18px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.8;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .cf-icon-button:hover,
  .cf-folder-row:hover,
  .cf-conversation:hover,
  .cf-menu-item:hover {
    background: color-mix(in srgb, CanvasText 8%, transparent);
  }

  .cf-icon-button:disabled {
    cursor: default;
    opacity: 0.38;
  }

  .cf-search {
    display: block;
    width: calc(100% - 40px);
    height: 32px;
    margin: 4px 20px 8px;
    border: 1px solid color-mix(in srgb, CanvasText 14%, transparent);
    border-radius: 8px;
    background: transparent;
    color: inherit;
    font: inherit;
    padding: 0 10px;
  }

  .cf-bulk {
    display: grid;
    gap: 8px;
    margin: 4px 20px 8px;
    padding: 8px;
    border: 1px solid color-mix(in srgb, CanvasText 10%, transparent);
    border-radius: 10px;
    background: color-mix(in srgb, CanvasText 4%, transparent);
  }

  .cf-select {
    width: 100%;
    height: 30px;
    border: 1px solid color-mix(in srgb, CanvasText 12%, transparent);
    border-radius: 8px;
    background: Canvas;
    color: CanvasText;
    font: inherit;
    padding: 0 8px;
  }

  .cf-history-list {
    display: grid;
    gap: 1px;
    max-height: 220px;
    overflow: auto;
  }

  .cf-history-row {
    display: flex;
    align-items: center;
    gap: 8px;
    min-height: 30px;
    border-radius: 8px;
    padding: 4px 6px;
    color: color-mix(in srgb, CanvasText 80%, transparent);
    cursor: pointer;
  }

  .cf-history-row:hover {
    background: color-mix(in srgb, CanvasText 8%, transparent);
  }

  .cf-history-row input {
    width: 15px;
    height: 15px;
    margin: 0;
    accent-color: currentColor;
  }

  .cf-history-title {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .cf-bulk-actions {
    display: flex;
    gap: 6px;
  }

  .cf-text-button {
    height: 30px;
    border: 0;
    border-radius: 8px;
    background: color-mix(in srgb, CanvasText 8%, transparent);
    color: inherit;
    cursor: pointer;
    flex: 1;
    font: inherit;
    padding: 0 10px;
  }

  .cf-text-button:hover {
    background: color-mix(in srgb, CanvasText 12%, transparent);
  }

  .cf-text-button:disabled {
    cursor: default;
    opacity: 0.45;
  }

  .cf-list {
    display: grid;
    gap: 2px;
    padding: 0 8px;
  }

  .cf-folder-block,
  .cf-conversation-item {
    display: grid;
    gap: 1px;
    position: relative;
  }

  .cf-folder-row {
    display: flex;
    align-items: center;
    min-height: 36px;
    gap: 8px;
    border-radius: 8px;
    padding: 0 12px;
    color: inherit;
    position: relative;
    width: 100%;
  }

  .cf-folder-row[data-active="true"] {
    background: color-mix(in srgb, CanvasText 10%, transparent);
  }

  .cf-conversation-row {
    gap: 6px;
    padding: 0 6px 0 12px;
  }

  .cf-conversation-row .cf-icon-button {
    flex: 0 0 26px;
    margin-left: 4px;
  }

  .cf-folder-main {
    display: flex;
    align-items: center;
    min-width: 0;
    flex: 1;
    gap: 8px;
    border: 0;
    background: transparent;
    color: inherit;
    cursor: pointer;
    font: inherit;
    padding: 0;
    text-align: left;
  }

  .cf-folder-icon {
    display: inline-grid;
    flex: none;
    place-items: center;
    color: color-mix(in srgb, CanvasText 70%, transparent);
  }

  .cf-name,
  .cf-conversation {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .cf-name {
    min-width: 0;
    flex: 1;
    font-weight: 500;
  }

  .cf-children {
    display: grid;
    gap: 1px;
    margin: 0 0 4px;
  }

  .cf-conversation {
    flex: 1 1 0;
    display: block;
    min-width: 0;
    width: 0;
    min-height: 28px;
    border-radius: 8px;
    color: color-mix(in srgb, CanvasText 76%, transparent);
    padding: 5px 0;
    text-align: left;
    text-decoration: none;
  }

  .cf-menu {
    position: absolute;
    right: 0;
    top: calc(100% + 4px);
    z-index: 2147483647;
    display: grid;
    width: 188px;
    gap: 2px;
    border: 1px solid color-mix(in srgb, CanvasText 12%, transparent);
    border-radius: 12px;
    padding: 8px;
    background: Canvas;
    color: CanvasText;
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.18);
  }

  .cf-menu-item {
    display: flex;
    align-items: center;
    gap: 12px;
    min-height: 36px;
    width: 100%;
    border: 0;
    border-radius: 8px;
    background: transparent;
    color: inherit;
    cursor: pointer;
    font: inherit;
    padding: 0 10px;
    text-align: left;
  }

  .cf-menu-item svg {
    flex: none;
    width: 18px;
    height: 18px;
  }

  .cf-menu-item[data-danger="true"] {
    color: #d93025;
  }

  .cf-menu-item:disabled {
    cursor: default;
    opacity: 0.42;
  }

  .cf-menu-item:disabled:hover {
    background: transparent;
  }

  .cf-menu-divider {
    height: 1px;
    margin: 4px 2px;
    background: color-mix(in srgb, CanvasText 10%, transparent);
  }

  .cf-empty,
  .cf-error {
    padding: 6px 12px 8px 54px;
    color: color-mix(in srgb, CanvasText 56%, transparent);
    font-size: 13px;
  }

  .cf-error {
    color: color-mix(in srgb, red 72%, CanvasText);
  }
`;class Q{constructor(e){p(this,"shadow");p(this,"state",{version:1,folders:[],conversations:[]});p(this,"currentConversation",null);p(this,"expandedFolderIds",new Set);p(this,"collapsed",!1);p(this,"searchOpen",!1);p(this,"bulkOpen",!1);p(this,"bulkFolderId",null);p(this,"menuPortal",null);p(this,"menuCloseController",null);p(this,"selectedHistoryIds",new Set);p(this,"query","");p(this,"error",null);this.shadow=e.shadowRoot??e.attachShadow({mode:"open"})}async init(){this.currentConversation=v(),await this.refreshState(),this.render()}async handleRouteChange(){this.currentConversation=v(),this.render()}async refreshState(){var e;this.state=await T(),(!this.bulkFolderId||!this.state.folders.some(t=>t.id===this.bulkFolderId))&&(this.bulkFolderId=((e=this.state.folders[0])==null?void 0:e.id)??null),this.expandedFolderIds.size===0&&this.state.folders[0]&&this.expandedFolderIds.add(this.state.folders[0].id)}setError(e){this.error=e instanceof Error?e.message:String(e),this.render()}clearError(){this.error=null}element(e,t,n){const o=document.createElement(e);return t&&(o.className=t),n!==void 0&&(o.textContent=n),o}iconButton(e,t,n){const o=this.element("button","cf-icon-button");return o.type="button",o.title=t,o.innerHTML=e,o.addEventListener("click",i=>{i.stopPropagation(),i.preventDefault(),n(o)}),o}closeMenu(){var e,t;(e=this.menuCloseController)==null||e.abort(),this.menuCloseController=null,(t=this.menuPortal)==null||t.remove(),this.menuPortal=null}showMenu(e,t){this.closeMenu();const n=e.getBoundingClientRect(),o=204,i=document.createElement("div");i.style.position="fixed",i.style.left=`${Math.min(n.right+8,window.innerWidth-o-8)}px`,i.style.top=`${Math.min(n.top,window.innerHeight-260)}px`,i.style.zIndex="2147483647",i.style.display="grid",i.style.width=`${o}px`,i.style.gap="2px",i.style.border="1px solid rgba(0, 0, 0, 0.12)",i.style.borderRadius="14px",i.style.padding="8px",i.style.background="Canvas",i.style.color="CanvasText",i.style.boxShadow="0 12px 30px rgba(0, 0, 0, 0.18)",i.style.font='14px ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';for(const d of t){if(d.dividerBefore){const u=document.createElement("div");u.style.height="1px",u.style.margin="4px 2px",u.style.background="rgba(0, 0, 0, 0.12)",i.append(u)}const s=document.createElement("button");s.type="button",s.disabled=!!d.disabled,s.title=d.title??d.label,s.innerHTML=`${d.icon}<span>${d.label}</span>`;const c=s.querySelector("svg");c&&(c.style.flex="none",c.style.width="18px",c.style.height="18px",c.style.fill="none",c.style.stroke="currentColor",c.style.strokeWidth="1.8",c.style.strokeLinecap="round",c.style.strokeLinejoin="round"),s.style.display="flex",s.style.alignItems="center",s.style.gap="12px",s.style.minHeight="38px",s.style.width="100%",s.style.border="0",s.style.borderRadius="9px",s.style.background="transparent",s.style.color=d.danger?"#d93025":"inherit",s.style.cursor=d.disabled?"default":"pointer",s.style.font="inherit",s.style.opacity=d.disabled?"0.42":"1",s.style.padding="0 10px",s.style.textAlign="left",s.addEventListener("mouseenter",()=>{s.disabled||(s.style.background="rgba(0, 0, 0, 0.08)")}),s.addEventListener("mouseleave",()=>{s.style.background="transparent"}),s.addEventListener("click",u=>{u.stopPropagation(),u.preventDefault(),!s.disabled&&(this.closeMenu(),d.onClick())}),i.append(s)}this.menuPortal=i,document.body.append(i);const a=new AbortController;this.menuCloseController=a,window.addEventListener("scroll",()=>this.closeMenu(),{signal:a.signal,capture:!0}),window.addEventListener("resize",()=>this.closeMenu(),{signal:a.signal}),document.addEventListener("pointerdown",d=>{!i.contains(d.target)&&!e.contains(d.target)&&this.closeMenu()},{signal:a.signal,capture:!0})}showHeaderMenu(e){this.showMenu(e,[{icon:h.search,label:l.search,onClick:()=>{this.searchOpen=!this.searchOpen,this.render()}},{icon:h.folderPlus,label:l.createFolder,onClick:()=>this.handleCreateFolder()},{icon:h.batch,label:l.batchAdd,onClick:()=>{this.bulkOpen=!this.bulkOpen,this.render()}}])}showFolderMenu(e,t){this.showMenu(e,[{icon:h.plus,label:l.addCurrent,title:this.currentConversation?l.addCurrent:l.noCurrent,disabled:!this.currentConversation,onClick:()=>this.handleAssignCurrent(t.id)},{icon:h.batch,label:l.batchAdd,onClick:()=>{this.bulkFolderId=t.id,this.bulkOpen=!0,this.render()}},{icon:h.edit,label:l.renameFolder,onClick:()=>this.handleRenameFolder(t)},{icon:h.trash,label:l.deleteFolder,danger:!0,dividerBefore:!0,onClick:()=>this.handleDeleteFolder(t)}])}showConversationMenu(e,t){this.showMenu(e,[{icon:h.edit,label:l.renameConversation,onClick:()=>this.handleRenameConversation(t)},{icon:h.trash,label:l.remove,danger:!0,onClick:()=>this.handleUnassignConversation(t)}])}render(){const e=this.element("style");e.textContent=J;const t=this.element("section","cf-section");t.append(this.renderHeader()),this.searchOpen&&t.append(this.renderSearch()),this.bulkOpen&&t.append(this.renderBulkPicker()),this.error&&t.append(this.element("div","cf-error",this.error)),this.collapsed||t.append(this.renderFolders()),this.shadow.replaceChildren(e,t)}renderHeader(){const e=this.element("div","cf-header");return e.append(this.element("div","cf-title",l.folders)),e.append(this.iconButton(h.more,l.menu,t=>this.showHeaderMenu(t)),this.iconButton(this.collapsed?h.chevronRight:h.chevronDown,this.collapsed?l.expand:l.collapse,()=>{this.collapsed=!this.collapsed,this.render()})),e}renderSearch(){const e=this.element("input","cf-search");return e.type="search",e.placeholder=l.searchPlaceholder,e.value=this.query,e.addEventListener("input",()=>{this.query=e.value,this.render();const t=this.shadow.querySelector(".cf-search");t==null||t.focus(),t==null||t.setSelectionRange(t.value.length,t.value.length)}),e}renderBulkPicker(){const e=this.element("div","cf-bulk"),t=this.element("select","cf-select");t.title=l.selectFolder,t.disabled=this.state.folders.length===0;for(const s of this.state.folders){const c=this.element("option");c.value=s.id,c.textContent=s.name,c.selected=s.id===this.bulkFolderId,t.append(c)}t.addEventListener("change",()=>{this.bulkFolderId=t.value});const n=this.element("div","cf-history-list"),o=b();if(!o.length)n.append(this.element("div","cf-empty",l.noHistory));else for(const s of o){const c=this.element("label","cf-history-row"),u=this.element("input");u.type="checkbox",u.checked=this.selectedHistoryIds.has(s.id),u.addEventListener("change",()=>{u.checked?this.selectedHistoryIds.add(s.id):this.selectedHistoryIds.delete(s.id)}),c.append(u,this.element("span","cf-history-title",s.title)),n.append(c)}const i=this.element("div","cf-bulk-actions"),a=this.element("button","cf-text-button",l.addSelected);a.type="button",a.disabled=!this.bulkFolderId||!o.length,a.addEventListener("click",()=>{this.handleBulkAssign(o)});const d=this.element("button","cf-text-button",l.cancel);return d.type="button",d.addEventListener("click",()=>{this.bulkOpen=!1,this.selectedHistoryIds.clear(),this.render()}),i.append(a,d),e.append(t,n,i),e}renderFolders(){const e=this.element("div","cf-list"),t=this.filteredFolders();if(!t.length)return e.append(this.element("div","cf-empty",l.noFolders)),e;for(const n of t)e.append(this.renderFolderBlock(n));return e}renderFolderBlock(e){const t=this.element("div","cf-folder-block");return t.append(this.renderFolderRow(e)),this.expandedFolderIds.has(e.id)&&t.append(this.renderConversations(e)),t}renderFolderRow(e){const t=this.element("div","cf-folder-row"),n=!!(this.currentConversation&&this.state.conversations.some(i=>{var a;return i.id===((a=this.currentConversation)==null?void 0:a.id)&&i.folderId===e.id}));t.dataset.active=String(n);const o=this.element("button","cf-folder-main");return o.type="button",o.append(this.iconSpan(h.folder),this.element("span","cf-name",e.name)),o.addEventListener("click",()=>{this.toggleFolder(e.id)}),t.append(o,this.iconButton(h.more,l.menu,i=>this.showFolderMenu(i,e)),this.iconButton(this.expandedFolderIds.has(e.id)?h.chevronDown:h.chevronRight,l.expand,()=>this.toggleFolder(e.id))),t}renderConversations(e){const t=this.element("div","cf-children"),n=this.filteredConversations(e.id);if(!n.length)return t.append(this.element("div","cf-empty",l.noConversations)),t;for(const o of n){const i=this.element("div","cf-conversation-item"),a=this.element("div","cf-folder-row");a.classList.add("cf-conversation-row");const d=this.element("a","cf-conversation",o.title);d.href=o.url,d.title=o.title,a.append(d,this.iconButton(h.more,l.menu,s=>this.showConversationMenu(s,o))),i.append(a),t.append(i)}return t}iconSpan(e){const t=this.element("span","cf-folder-icon");return t.innerHTML=e,t}filteredFolders(){const e=this.query.trim().toLowerCase();return e?this.state.folders.filter(t=>t.name.toLowerCase().includes(e)?!0:this.state.conversations.some(n=>n.folderId===t.id&&n.title.toLowerCase().includes(e))):this.state.folders}filteredConversations(e){const t=this.query.trim().toLowerCase();return this.state.conversations.filter(n=>n.folderId!==e?!1:!t||n.title.toLowerCase().includes(t))}toggleFolder(e){this.expandedFolderIds.has(e)?this.expandedFolderIds.delete(e):this.expandedFolderIds.add(e),this.render()}async handleCreateFolder(){const e=window.prompt(l.folderNamePrompt);if(e!==null){this.clearError();try{const t=await W(e);this.expandedFolderIds.add(t.id),this.bulkFolderId=t.id,await this.refreshState(),this.render()}catch(t){this.setError(t)}}}async handleAssignCurrent(e){this.clearError();try{await Y(e,this.currentConversationWithSidebarTitle()),this.expandedFolderIds.add(e),await this.refreshState(),this.render()}catch(t){this.setError(t)}}currentConversationWithSidebarTitle(){return this.currentConversation?b().find(t=>{var n;return t.id===((n=this.currentConversation)==null?void 0:n.id)})??this.currentConversation:null}async handleBulkAssign(e){if(!this.bulkFolderId)return;const t=e.filter(n=>this.selectedHistoryIds.has(n.id));if(t.length){this.clearError();try{await Z(t,this.bulkFolderId),this.expandedFolderIds.add(this.bulkFolderId),this.bulkOpen=!1,this.selectedHistoryIds.clear(),await this.refreshState(),this.render()}catch(n){this.setError(n)}}}async handleRenameFolder(e){const t=window.prompt(l.newFolderPrompt,e.name);if(t!==null){this.clearError();try{await _(e.id,t),await this.refreshState(),this.render()}catch(n){this.setError(n)}}}async handleDeleteFolder(e){if(window.confirm(`${l.deleteConfirmPrefix}“${e.name}”${l.deleteConfirmSuffix}`)){this.clearError();try{this.expandedFolderIds.delete(e.id),await j(e.id),await this.refreshState(),this.render()}catch(t){this.setError(t)}}}async handleRenameConversation(e){const t=window.prompt(l.renameConversation,e.title);if(t!==null){this.clearError();try{await K(e.id,t),await this.refreshState(),this.render()}catch(n){this.setError(n)}}}async handleUnassignConversation(e){this.clearError();try{await X(e.id),await this.refreshState(),this.render()}catch(t){this.setError(t)}}}function w(){return Array.from(document.querySelectorAll("nav, aside, [data-testid='history-sidebar']")).find(e=>{const t=e.innerText||"",n=e.getBoundingClientRect();return n.width>=180&&n.width<=420&&/(\u65b0\u804a\u5929|\u6700\u8fd1|ChatGPT|Search)/.test(t)})??null}function I(r,e){var o;const t=document.createTreeWalker(r,NodeFilter.SHOW_TEXT);let n=t.nextNode();for(;n;){const i=(o=n.textContent)==null?void 0:o.trim();if(i&&e.some(a=>i===a||i.includes(a)))return n.parentElement;n=t.nextNode()}return null}function ee(r){const e=I(r,["最近","Recent"]);if(!e)return null;let t=e;for(;t.parentElement&&t.parentElement!==r;){const n=t.parentElement,o=n.getBoundingClientRect();if(o.height>18&&o.height<=60&&o.width>=120){t=n;break}t=n}return t}function te(r,e){let t=r;for(;t.parentElement&&t.parentElement!==e;){const n=t.parentElement,o=n.getBoundingClientRect();if(t=n,o.height>24&&o.height<=64&&o.width>=120)break}return t}function ne(r){const e=I(r,["更多","More"]);return e?te(e,r):null}function M(r,e){const t=ne(e);if(t!=null&&t.parentElement){t.parentElement.insertBefore(r,t.nextSibling);return}const n=ee(e);n!=null&&n.parentElement?n.parentElement.insertBefore(r,n):e.append(r)}function b(){const r=w();if(!r)return[];const e=new Map,t=Array.from(r.querySelectorAll("a[href]"));for(const n of t){const o=n.href,i=C(o);if(!i||e.has(i))continue;const a=n.innerText||n.title||n.getAttribute("aria-label")||"",d=k(a.replace(/\s+/g," "));e.set(i,{id:i,title:d,url:o})}return Array.from(e.values())}function re(){const r=document.getElementById(x);if(r)return r;const e=document.createElement("div");e.id=x,e.style.display="block",e.style.flex="none",e.style.width="100%";const t=w();return t?(M(e,t),e):(document.documentElement.append(e),e.hidden=!0,e)}function oe(r){const e=()=>{if(!r.isConnected||r.hidden){const n=w();if(!n)return;r.hidden=!1,M(r,n)}},t=new MutationObserver(e);return t.observe(document.documentElement,{childList:!0,subtree:!0}),e(),()=>t.disconnect()}async function ie(){const r=re(),e=new Q(r);await e.init(),oe(r),$(()=>{e.handleRouteChange()}),chrome.storage.onChanged.addListener((t,n)=>{n==="sync"&&t[g]&&e.refreshState().then(()=>e.handleRouteChange())})}ie().catch(r=>{var e;console.error("ChatGPT Folders failed to initialize",r),(e=document.getElementById(x))==null||e.remove()});
